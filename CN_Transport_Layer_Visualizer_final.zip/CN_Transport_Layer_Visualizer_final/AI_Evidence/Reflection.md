# Reflection – Computer Networks Transport Layer Assignment 2

## Introduction

This assignment helped me understand the Transport Layer of Computer Networks in a more practical and visual way. The main objective was to extend my previous Application Layer dashboard and add a Transport Layer visualization for Browsing, Mail, and Streaming activities.

Instead of only studying TCP and UDP theoretically, I implemented their behaviour in an interactive dashboard. This helped me connect the concepts learned in class with how communication is represented step by step.

## My Approach and Contribution

I developed the project myself and worked on the structure, implementation, testing, and final integration of the dashboard. I first understood the assignment requirements and then extended the existing dashboard while keeping the original dual-panel structure.

I implemented three activities: Browsing, Mail, and Streaming. The dashboard provides an Application Layer view as well as a Transport Layer view. I also added controls such as Previous, Next, Auto Play, Pause, and Replay so that the protocol steps can be viewed progressively.

For the Transport Layer, I implemented simulated TCP communication. The visualization includes the TCP three-way handshake using SYN, SYN-ACK, and ACK, followed by data transfer and connection termination using FIN and ACK. Important packet information such as sequence number, acknowledgement number, window size, flags, length, and direction is also displayed.

I tested the project on my computer and checked the different activities and controls to make sure the dashboard was working correctly.

## Role of AI

I used ChatGPT as a guide and coding assistant during the development of the project. It helped me understand some of the requirements, provided code assistance when needed, explained networking concepts, and helped me debug errors.

However, the project was not simply submitted as an AI-generated output. I integrated the code into my project, ran it myself, tested the features, identified problems, and made the final decisions and changes.

Using AI was particularly helpful when I faced programming or implementation problems. Instead of only receiving an answer, I could understand the issue, apply the suggested solution, and verify whether it worked in my project.

## Challenges Faced

One of the main challenges was connecting the Application Layer activities with the corresponding Transport Layer behaviour. I had to make sure that changing an activity also changed the protocol visualization appropriately.

Another challenge was understanding how TCP communication should be represented visually. Concepts such as sequence numbers, acknowledgement numbers, flags, and connection termination were easier to understand after implementing them as progressive steps.

I also faced programming and setup issues while running the project. Debugging these problems helped me become more comfortable with Python, FastAPI, HTML, CSS, and JavaScript and taught me how to test and correct a project instead of assuming that the first version will work.

## What I Learned

The most important thing I learned from this assignment was the relationship between the Application Layer and Transport Layer. For example, browsing and email communication use TCP to provide reliable communication, while the Transport Layer manages the connection and data transfer underneath the application-level protocols.

I also learned more about the TCP three-way handshake and connection termination. Visualizing SYN, SYN-ACK, ACK, data transfer, and FIN/ACK messages made these concepts easier to understand than reading them only from notes.

Apart from networking concepts, I improved my practical programming skills. I learned more about organizing a web project, running a FastAPI application, debugging errors, modifying an existing interface, and testing different features systematically.

## Reflection on the Final Project

The final project gave me a better understanding of how networking concepts can be represented through software. The visualizer is an educational simulation rather than a real packet-capture system, but it provides a clear step-by-step representation of the protocols required by the assignment.

Overall, this assignment improved both my Computer Networks knowledge and my practical development skills. It also taught me that AI tools can be useful for guidance and problem-solving, but the student still needs to understand, test, verify, and take responsibility for the final implementation.
