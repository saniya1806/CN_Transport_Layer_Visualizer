# AI Usage Log / Artifacts – Assignment 2

## 1. Student Contribution

I developed and completed the Computer Networks Transport Layer Visualizer project myself. I planned the project structure, decided the required features, created and organized the project files, implemented and tested the dashboard, and made the final changes according to the assignment requirements.

I personally ran the project, checked the interface, tested Browsing, Mail, and Streaming activities, and verified the Application Layer and Transport Layer views. I also checked the TCP steps, controls, activity logs, and overall working of the dashboard.

## 2. AI Tool Used

**AI Platform:** ChatGPT
**Model:** GPT-5.6 Luna

ChatGPT was used mainly for **guidance, explanations, coding assistance, debugging help, and suggestions** during development.

## 3. How ChatGPT Assisted Me

ChatGPT helped me with:

* Understanding the requirements of the Transport Layer assignment.
* Planning how to extend the existing Application Layer dashboard.
* Providing HTML, CSS, JavaScript, and Python code when required.
* Guiding me on how to create and organize the project files.
* Explaining TCP concepts such as SYN, SYN-ACK, ACK, sequence numbers, acknowledgement numbers, window size, flags, and FIN/ACK termination.
* Helping design the Application Layer / Transport Layer toggle.
* Helping implement the Browsing, Mail, and Streaming transport simulations.
* Debugging errors when the application did not run correctly.
* Giving step-by-step instructions for running the FastAPI application and testing it locally.
* Suggesting improvements to the interface and functionality.

## 4. My Work vs AI Assistance

The project was **developed and completed by me**. I used ChatGPT as a coding and learning assistant.

I decided what features were required, applied the instructions to my project, ran the code, tested the dashboard, identified problems, and made the final decisions about the project.

ChatGPT mainly provided **guidance, explanations, code assistance, and debugging support**. I did not simply submit an AI-generated project without testing it. I integrated the code into my project and verified its functionality myself.

## 5. Example Prompts / Assistance

Some of the types of instructions I gave to ChatGPT were:

1. Asked for guidance on extending the existing Application Layer dashboard for the Transport Layer assignment.

2. Asked for code assistance to add TCP three-way handshake, data transfer, and connection termination.

3. Asked how to display TCP fields such as:

   * Sequence Number
   * Acknowledgement Number
   * Window Size
   * Flags
   * Length
   * Direction

4. Asked for help debugging the project when errors occurred while running it.

5. Asked for step-by-step instructions for running the FastAPI project and testing the dashboard.

## 6. Verification and Testing

After receiving coding assistance, I ran the project on my computer and tested the implemented features myself.

I checked:

* Browsing activity
* Mail activity
* Streaming activity
* Application Layer view
* Transport Layer view
* TCP handshake
* TCP data-transfer steps
* TCP connection termination
* Previous / Next controls
* Auto Play / Pause
* Replay
* Activity logs
* Overall dashboard functionality

## 7. Limitations of AI Assistance

The AI-generated code and protocol logic still required my testing and verification. I checked the TCP sequence and the behaviour of the visualizer before considering the project complete.

The Transport Layer implementation is an **educational simulation**, not a real packet capture system. ChatGPT helped me implement the simulation, while I tested and finalized the working project.

## 8. Evidence / Artifacts

The AI assistance can be demonstrated through:

* ChatGPT conversation history
* Screenshots of the AI-assisted development process
* Code generated or modified with AI assistance
* Debugging conversations
* Final working dashboard screenshots

## 9. Conclusion

ChatGPT was used as a **guide, coding assistant, and debugging assistant**, while the planning, integration, testing, verification, and final completion of the project were done by me.
