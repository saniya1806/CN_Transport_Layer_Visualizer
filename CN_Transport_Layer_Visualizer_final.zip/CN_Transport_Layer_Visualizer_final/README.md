# Computer Networks – Application and Transport Layer Visualizer

## Project Overview

This project is a web-based visualizer for demonstrating the working of
Application Layer and Transport Layer protocols.

The project provides a simple two-panel interface where the user can
perform network activities on the left side and observe the corresponding
protocol steps on the right side.

## Technologies Used

- Python
- FastAPI
- Uvicorn
- HTML
- CSS
- JavaScript

## Application Layer Features

### 1. Web Browsing
Demonstrates:
- DNS Query
- DNS Response
- HTTP GET Request
- HTTP 200 OK Response

### 2. Email
Demonstrates the SMTP communication sequence used for sending an email.

### 3. Streaming
Demonstrates:
- DNS communication
- HTTP playlist/manifest request
- Video segment requests and responses

Different video quality options are also available.

## Transport Layer Features

### TCP

The TCP visualizer demonstrates:

1. SYN
2. SYN-ACK
3. ACK
4. Data Transfer
5. ACK
6. FIN
7. ACK
8. FIN
9. Final ACK

Packet information such as source port, destination port, flags,
sequence number, and acknowledgement number is displayed.

### UDP

The UDP visualizer demonstrates:

1. UDP Datagram
2. UDP Response
3. Another UDP Datagram
4. UDP Response

The visualization also displays basic UDP information such as source
port, destination port, length, and checksum.

## Visualization Controls

The protocol visualization includes:

- Previous
- Next
- Auto Play
- Pause
- Replay

These controls allow the user to move through the protocol sequence
step by step.

## How to Run the Project

### Step 1: Open Terminal

Go to the project folder:

```bash
cd ~/Desktop/CN_Transport_Layer_Visualizer
